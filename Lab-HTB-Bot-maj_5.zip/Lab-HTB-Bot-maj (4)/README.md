# Bot Lab-HTB

Une commande, `/installer_lab`, crée ou remet en place les rôles, les salons, leurs permissions et leurs messages de présentation sur **Lab-HTB**. Ce code utilise ton application Discord **HTB Bot** déjà créée. Le bot réutilise les rôles et salons du même nom déjà présents. Il ne supprime aucun salon, rôle ou message existant.

## Mise en route

1. Dans le [portail développeur Discord](https://discord.com/developers/applications/1562386738779791430/bot), ouvre **HTB Bot > Bot** et copie son token. S'il n'est plus affiché, régénère-le toi-même. Ne l'envoie à personne.
2. Copie `.env.example` en `.env`, puis remplace `COLLER_LE_TOKEN_DU_BOT_ICI` par le token. Le fichier `.env` reste sur ton ordinateur.
3. [Ajoute HTB Bot à Lab-HTB](https://discord.com/oauth2/authorize?client_id=1562386738779791430&permissions=268512336&scope=bot%20applications.commands&guild_id=1562386314597236796&disable_guild_select=true). Le lien demande : gérer les salons et rôles, voir et envoyer des messages, lire l'historique, ajouter des réactions et gérer les messages. Il ne demande pas la permission **Administrateur**.
4. Dans **Paramètres du serveur > Rôles**, place le rôle **HTB Bot** au-dessus des rôles **Étudiant, Encadrant, Débutant, Intermédiaire et Avancé** déjà présents. Discord empêche un bot d'attribuer un rôle situé au-dessus du sien ; cette manipulation unique est nécessaire sur le serveur actuel.
5. Double-clique `lancer.bat`. Le premier lancement installe les dépendances dans `.venv`. Garde la fenêtre ouverte pendant l'utilisation du bot.
6. Dans Lab-HTB, avec le compte propriétaire ou administrateur, tape **`/installer_lab`**. Le bot répondra en privé avec le résultat et le lien vers le message de choix du niveau. Une seconde exécution complète une installation interrompue sans créer de doublons.

Le serveur et l'application sont déjà identifiés dans `.env.example`. Si tu changes de serveur, modifie `GUILD_ID` avant de lancer le bot.

## Ce que la commande prépare

| Espace | Salons | Accès |
|---|---|---|
| 👋 ACCUEIL | `👋・bienvenue`, `🧭・guide-du-serveur`, `🛡️・règles`, `📢・annonces`, `🎯・choix-du-niveau` | Tous peuvent lire. Seuls les encadrants et le bot publient. Tous peuvent réagir dans le choix du niveau. |
| 🧪 LAB HTB | `📋・consignes`, `🖥️・machines`, `📚・ressources`, `🧩・entraide`, `📈・progression`, `🚀・avance`, `🏆・classement` | Rôle Étudiant ou Encadrant. Les étudiants écrivent dans l'entraide et la progression. `🚀・avance` est réservé au bot. |
| 💬 DISCUSSIONS | `💬・général` | Rôle Étudiant ou Encadrant ; discussion ouverte. |
| 🔊 VOCAL | `💬・Général`, `🧩・Entraide` | Rôle Étudiant ou Encadrant. |
| 🔐 ADMINISTRATION | `🔐・équipe`, `🤖・journal-bot` | Encadrants et propriétaire du serveur seulement. Cet espace n'apparaît pas dans le guide public. |

Les catégories par défaut **Salons textuels** et **Salons vocaux** sont renommées **DISCUSSIONS** et **VOCAL** si elles existent. Les permissions des catégories et des salons listés ci-dessus sont appliquées par la commande. Les autres salons du serveur restent en place ; leur visibilité peut changer s'ils héritent des permissions d'une catégorie renommée.

Le bot crée ou réutilise les rôles **Étudiant**, **Encadrant**, **Débutant**, **Intermédiaire** et **Avancé**. Les rôles de niveau n'ont aucun pouvoir de modération. **Encadrant** donne accès aux salons privés et à la gestion des messages des salons du lab, sans accorder la permission serveur **Administrateur**. Un étudiant réagit avec 🟢, 🔵 ou 🟣 dans `#choix-du-niveau` : le bot lui donne **Étudiant** et un seul rôle de niveau. Une nouvelle réaction change son niveau et retire l'ancien rôle. Le propriétaire peut nommer un encadrant avec **`/nommer_encadrant membre:@utilisateur`**.

Le bot publie une carte complète dans `🧭・guide-du-serveur`, avec les espaces publics et étudiants, leurs objectifs et des liens directs. L'administration privée n'y est pas mentionnée. Les autres salons restent propres et vides ; seul `🎯・choix-du-niveau` conserve le message indispensable aux réactions. Une nouvelle exécution de `/installer_lab` actualise le guide sans créer de doublon. Le bot ne se connecte pas à l'API Hack The Box : les points sont saisis par les encadrants.

## Suivi de progression

**Barème XP** : lab Very Easy 10, Easy 20, Medium 30, Hard 40, Insane 50 XP (divisé par 2 si l'IA est utilisée) ; 5 XP par étape de module CJCA. Un lab ne rapporte son XP qu'une fois validé par un encadrant.

| Commande | Qui | Effet |
|---|---|---|
| **`/lab nom difficulte ia`** | Étudiant | Déclare un lab terminé. Une demande part dans le salon de validation des encadrants (✅ valide, ❌ refuse). |
| **`/module parcours module etapes`** | Étudiant | Enregistre ses étapes faites sur un module CJCA (ex. 15/24). Quand les 20 modules sont complets, le rôle **CJCA terminé** est attribué. |
| **`/classement`** | Tous | Affiche le top 15 par XP. Le message de `🏆・classement` se met à jour automatiquement. |
| **`/avance membre`** | Encadrant | Bilan privé d'un étudiant : labs (difficulté, IA, statut) et modules. |
| **`/corriger lab`** / **`/corriger module`** | Encadrant | Valide, refuse ou supprime un lab ; corrige les étapes d'un module. |
| **`/export`** | Encadrant | Fichier CSV de l'avancement de tous les étudiants. |
| **`/retard [jours]`** | Encadrant | Étudiants sans activité depuis X jours (7 par défaut). |
| **`/stats`** | Encadrant | Statistiques des labs et des modules. |

Les données sont dans `state.json`. Les barèmes sont dans `LAB_DIFFICULTIES` et `XP_PAR_ETAPE`, le salon de validation dans `LAB_VALIDATION_CHANNEL_ID`, la liste des modules dans `ACADEMY_MODULES` (`server_plan.py`). Le bot doit pouvoir écrire dans le salon de validation.

## Si la commande échoue

- **Rôle du bot trop bas** : remonte **HTB Bot** au-dessus des rôles Lab-HTB, puis relance `/installer_lab`.
- **Permissions manquantes** : réinvite le bot avec le lien de l'étape 3, puis relance la commande.
- **Commande invisible** : attends quelques secondes, vérifie que `lancer.bat` affiche « Commandes synchronisées », puis redémarre Discord.
- **Bot hors ligne** : la fenêtre `lancer.bat` doit rester ouverte, ou il faudra l'héberger sur une machine qui reste allumée.

Le token n'est jamais inscrit dans le code. `state.json` conserve uniquement les identifiants du message de choix du niveau pour que les réactions continuent à fonctionner après un redémarrage.
