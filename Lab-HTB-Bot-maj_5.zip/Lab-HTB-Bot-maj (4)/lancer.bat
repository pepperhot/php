@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  echo Fichier .env manquant. Copie .env.example en .env et colle le token du bot.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Python 3 est requis.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Installation des dependances impossible.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" bot.py
pause
